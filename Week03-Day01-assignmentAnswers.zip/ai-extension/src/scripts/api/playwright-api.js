/**
 * Playwright Python API Handler
 * Communicates with backend service for code generation
 * Port: 3001 (configurable in settings)
 */

class PlaywrightAPI {
  constructor(backendUrl = 'http://localhost:3001') {
    this.backendUrl = backendUrl.replace(/\/$/, ''); // Remove trailing slash
    this.apiEndpoint = `${this.backendUrl}/api/generate`;
  }

  /**
   * Update the backend URL
   */
  setBackendUrl(url) {
    this.backendUrl = url.replace(/\/$/, '');
    this.apiEndpoint = `${this.backendUrl}/api/generate`;
  }

  /**
   * Send code generation request to backend
   * 
   * @param {Object} params - Generation parameters
   * @param {string} params.domContent - Selected DOM HTML
   * @param {string} params.language - Programming language (python)
   * @param {string} params.framework - Framework name (playwright)
   * @param {string} params.generatorType - Code type (SINGLE_FILE, PAGE, FEATURE)
   * @param {string} params.provider - AI provider (groq, openai, testleaf)
   * @param {string} params.selectedModel - Model name
   * @param {string} params.apiKey - Provider API key
   * @param {string} params.userInput - Additional user instructions
   * 
   * @returns {Promise<{content: string}>} Generated code
   */
  async sendMessage(params, modelName) {
    try {
      const {
        domContent = '',
        language = 'python',
        framework = 'playwright',
        generatorType = 'SINGLE_FILE',
        provider = 'groq',
        apiKey = '',
        userInput = ''
      } = params;

      console.log('[PlaywrightAPI] Sending request to backend:', {
        backendUrl: this.backendUrl,
        generatorType,
        provider,
        model: modelName
      });

      // Check backend connectivity first
      await this.checkBackendHealth();

      const response = await fetch(this.apiEndpoint, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          domContent,
          language,
          framework,
          generatorType,
          provider,
          selectedModel: modelName,
          apiKey,
          userInput
        })
      });

      if (!response.ok) {
        const errorData = await response.text();
        console.error('[PlaywrightAPI] Response Error:', response.status, errorData);
        throw new Error(
          `Backend error: ${response.status} - ${errorData || 'Unknown error'}`
        );
      }

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Code generation failed');
      }

      console.log('[PlaywrightAPI] Successfully generated code');

      return {
        content: data.generatedCode,
        metadata: data.metadata
      };

    } catch (error) {
      console.error('[PlaywrightAPI] Error:', error);
      
      // Provide helpful error messages
      if (error.message.includes('fetch')) {
        throw new Error(
          `Backend unavailable at ${this.backendUrl}. ` +
          `Please start the backend server: npm start`
        );
      }
      
      throw error;
    }
  }

  /**
   * Check if backend server is healthy
   */
  async checkBackendHealth() {
    try {
      const healthUrl = `${this.backendUrl}/health`;
      const response = await fetch(healthUrl, {
        method: 'GET',
        timeout: 5000
      });

      if (!response.ok) {
        throw new Error(`Health check failed: ${response.status}`);
      }

      const data = await response.json();
      console.log('[PlaywrightAPI] Backend health check passed:', data);
      return true;

    } catch (error) {
      console.error('[PlaywrightAPI] Backend health check failed:', error);
      throw new Error(
        `Cannot reach backend at ${this.backendUrl}. ` +
        `Please ensure the backend server is running on port 3001.\n\n` +
        `To start the backend:\n` +
        `1. Navigate to the backend directory\n` +
        `2. Run: npm install\n` +
        `3. Run: npm start`
      );
    }
  }
}

// Make the class available globally
window.PlaywrightAPI = PlaywrightAPI;
