/**
 * Collection of default prompts for different use cases (ICE POT Format)
 */
export const DEFAULT_PROMPTS = {
 
  /**
   * Selenium Java Page Object Prompt (No Test Class)
   */
  SELENIUM_JAVA_PAGE_ONLY: `
    Instructions:
    - Generate ONLY a Selenium Java Page Object Class (no test code).
    - Add JavaDoc for methods & class.
    - Use Selenium 2.30+ compatible imports.
    - Use meaningful method names.
    - Do NOT include explanations or test code.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`

    Example:
    \`\`\`java
    package com.testleaf.pages;

    /**
     * Page Object for Component Page
     */
    public class ComponentPage {
        // Add methods as per the DOM
    }
    \`\`\`

    Persona:
    - Audience: Automation engineer focusing on maintainable POM structure.

    Output Format:
    - A single Java class inside a \`\`\`java\`\`\` block.

    Tone:
    - Clean, maintainable, enterprise-ready.
  `,

  /**
   * Cucumber Feature File Only Prompt
   */
  CUCUMBER_ONLY: `
    Instructions:
    - Generate ONLY a Cucumber (.feature) file.
    - Use Scenario Outline with Examples table.
    - Make sure every step is relevant to the provided DOM.
    - Do not combine multiple actions into one step.
    - Use South India realistic dataset (names, addresses, pin codes, mobile numbers).
    - Use dropdown values only from provided DOM.
    - Generate multiple scenarios if applicable.

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`

    Example:
    \`\`\`gherkin
    Feature: Login to OpenTaps

    Scenario Outline: Successful login with valid credentials
      Given I open the login page
      When I type "<username>" into the Username field
      And I type "<password>" into the Password field
      And I click the Login button
      Then I should be logged in successfully

    Examples:
      | username   | password  |
      | "testuser" | "testpass"|
      | "admin"    | "admin123"|
    \`\`\`

    Persona:
    - Audience: BDD testers who only need feature files.

    Output Format:
    - Only valid Gherkin in a \`\`\`gherkin\`\`\` block.

    Tone:
    - Clear, structured, executable.
  `,

  /**
   * Cucumber with Step Definitions
   */
  CUCUMBER_WITH_SELENIUM_JAVA_STEPS: `
    Instructions:
    - Generate BOTH:
      1. A Cucumber .feature file.
      2. A Java step definition class for selenium.
    - Do NOT include Page Object code.
    - Step defs must include WebDriver setup, explicit waits, and actual Selenium code.
    - Use Scenario Outline with Examples table (South India realistic data).

    Context:
    DOM:
    \`\`\`html
    \${domContent}
    \`\`\`
    URL: \${pageUrl}

    Example:
    \`\`\`gherkin
    Feature: Login to OpenTaps

    Scenario Outline: Successful login with valid credentials
      Given I open the login page
      When I type "<username>" into the Username field
      And I type "<password>" into the Password field
      And I click the Login button
      Then I should be logged in successfully

    Examples:
      | username   | password  |
\      | "admin"    | "admin123"|
    \`\`\`

    \`\`\`java
    package com.leaftaps.stepdefs;

    import io.cucumber.java.en.*;
    import org.openqa.selenium.*;
    import org.openqa.selenium.chrome.ChromeDriver;
    import org.openqa.selenium.support.ui.*;

    public class LoginStepDefinitions {
        private WebDriver driver;
        private WebDriverWait wait;

        @io.cucumber.java.Before
        public void setUp() {
            driver = new ChromeDriver();
            wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            driver.manage().window().maximize();
        }

        @io.cucumber.java.After
        public void tearDown() {
            if (driver != null) driver.quit();
        }

        @Given("I open the login page")
        public void openLoginPage() {
            driver.get("\${pageUrl}");
        }

        @When("I type {string} into the Username field")
        public void enterUsername(String username) {
            WebElement el = wait.until(ExpectedConditions.elementToBeClickable(By.id("username")));
            el.sendKeys(username);
        }

        @When("I type {string} into the Password field")
        public void enterPassword(String password) {
            WebElement el = wait.until(ExpectedConditions.elementToBeClickable(By.id("password")));
            el.sendKeys(password);
        }

        @When("I click the Login button")
        public void clickLogin() {
            driver.findElement(By.xpath("//button[contains(text(),'Login')]")).click();
        }

        @Then("I should be logged in successfully")
        public void verifyLogin() {
            WebElement success = wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("success")));
            assert success.isDisplayed();
        }
    }
    \`\`\`

    Persona:
    - Audience: QA engineers working with Cucumber & Selenium.

    Output Format:
    - Gherkin in \`\`\`gherkin\`\`\` block + Java code in \`\`\`java\`\`\` block.

    Tone:
    - Professional, executable, structured.
  `,

  /**
   * Playwright Python Single File
   */
  PLAYWRIGHT_PYTHON_SINGLE_FILE: `
    Instructions:
    - Generate a single Python test file using Playwright async API
    - Include all necessary imports (playwright, pytest, asyncio)
    - Create a pytest fixture for browser/page setup
    - Write test function using async/await syntax
    - Use meaningful test names and assertions
    - Include proper cleanup (context.close(), browser.close())
    - Do NOT include explanations, only code

    Context:
    DOM Elements to Automate:
    \`\`\`html
    \${domContent}
    \`\`\`

    Example:
    \`\`\`python
    import pytest
    from playwright.async_api import async_playwright, expect

    @pytest.fixture
    async def browser_context():
        async with async_playwright() as p:
            browser = await p.chromium.launch()
            context = await browser.new_context()
            page = await context.new_page()
            yield page
            await context.close()
            await browser.close()

    @pytest.mark.asyncio
    async def test_example(browser_context):
        page = browser_context
        await page.goto('https://example.com')
        await expect(page.locator('selector')).to_be_visible()
    \`\`\`

    Persona:
    - Audience: QA Automation Engineers using modern Playwright with Python
    - Focus: Clean, async/await patterns, proper fixture setup

    Output Format:
    - A complete, runnable Python test file inside a \`\`\`python\`\`\` block

    Tone:
    - Professional, clean, enterprise-ready code following PEP 8 standards
  `,

  /**
   * Playwright Python Page Object Model
   */
  PLAYWRIGHT_PYTHON_POM: `
    Instructions:
    - Generate Playwright Python Page Object Model (POM) structure
    - Create THREE separate code blocks: base_page.py, specific page class, and test file
    - Use async/await for all Playwright methods
    - Include type hints where applicable
    - Methods should have descriptive names and docstrings
    - Implement proper waits and locator strategies
    - Do NOT include explanations, only code

    Context:
    DOM Elements to Automate:
    \`\`\`html
    \${domContent}
    \`\`\`

    Example:
    \`\`\`python
    # base_page.py - Base Page Class
    from playwright.async_api import Page, expect

    class BasePage:
        def __init__(self, page: Page):
            self.page = page
        
        async def navigate(self, url: str):
            await self.page.goto(url)
        
        async def click(self, selector: str):
            await self.page.locator(selector).click()

    # pages/login_page.py - Specific Page Class
    from base_page import BasePage

    class LoginPage(BasePage):
        USERNAME_INPUT = 'input[name="username"]'
        PASSWORD_INPUT = 'input[name="password"]'
        LOGIN_BUTTON = 'button[type="submit"]'
        
        async def login(self, username: str, password: str):
            await self.page.fill(self.USERNAME_INPUT, username)
            await self.page.fill(self.PASSWORD_INPUT, password)
            await self.click(self.LOGIN_BUTTON)

    # test_login.py - Test File
    import pytest
    from playwright.async_api import async_playwright
    from pages.login_page import LoginPage

    @pytest.mark.asyncio
    async def test_user_login():
        async with async_playwright() as p:
            browser = await p.chromium.launch()
            page = await browser.new_page()
            login_page = LoginPage(page)
            await login_page.navigate('https://example.com/login')
            await login_page.login('user@example.com', 'password123')
            await browser.close()
    \`\`\`

    Persona:
    - Audience: Senior QA Engineers who value maintainability and scalability
    - Focus: Proper OOP design, reusable components

    Output Format:
    - THREE separate code blocks: base_page.py, page_name.py, test_page_name.py

    Tone:
    - Enterprise-grade, maintainable, scalable architecture with docstrings
  `,

  /**
   * Playwright Python Feature (pytest-bdd)
   */
  PLAYWRIGHT_PYTHON_FEATURE: `
    Instructions:
    - Generate Playwright Python test using pytest-bdd (Gherkin-style)
    - Create TWO code blocks: .feature file and conftest.py with step definitions
    - Use async/await for all Playwright methods
    - Include clear step definitions with proper assertions
    - Use @given, @when, @then decorators from pytest_bdd
    - Do NOT include explanations, only code

    Context:
    DOM Elements to Automate:
    \`\`\`html
    \${domContent}
    \`\`\`

    Example:
    \`\`\`gherkin
    Feature: User Login
      Scenario: Valid user login
        Given I am on the login page
        When I enter username and password
        And I click the login button
        Then I should see the dashboard
    \`\`\`

    \`\`\`python
    import pytest
    from playwright.async_api import async_playwright, expect
    from pytest_bdd import given, when, then, scenarios

    @pytest.fixture
    async def browser_context():
        async with async_playwright() as p:
            browser = await p.chromium.launch()
            context = await browser.new_context()
            page = await context.new_page()
            yield page
            await context.close()
            await browser.close()

    @given('I am on the login page')
    async def login_page(browser_context):
        await browser_context.goto('https://example.com/login')

    @when('I enter username and password')
    async def enter_credentials(browser_context):
        await browser_context.fill('input[name="username"]', 'user@example.com')
        await browser_context.fill('input[name="password"]', 'password123')

    @when('I click the login button')
    async def click_login(browser_context):
        await browser_context.click('button[type="submit"]')

    @then('I should see the dashboard')
    async def verify_dashboard(browser_context):
        await expect(browser_context.locator('h1')).to_contain_text('Dashboard')
    \`\`\`

    Persona:
    - Audience: BDD-focused QA teams using Cucumber/Gherkin style testing
    - Focus: Readable scenarios, maintainable step definitions

    Output Format:
    - Feature file in \`\`\`gherkin\`\`\` block + conftest.py in \`\`\`python\`\`\` block

    Tone:
    - Business-readable scenarios with clean, well-documented step definitions
  `
};

/**
 * Helper function to escape code blocks in prompts
 */
function escapeCodeBlocks(text) {
  return text.replace(/```/g, '\\`\\`\\`');
}

/**
 * Function to fill template variables in a prompt
 */
export function getPrompt(promptKey, variables = {}) {
  let prompt = DEFAULT_PROMPTS[promptKey];
  if (!prompt) {
    throw new Error(`Prompt not found: ${promptKey}`);
  }

  Object.entries(variables).forEach(([k, v]) => {
    const regex = new RegExp(`\\$\\{${k}\\}`, 'g');
    prompt = prompt.replace(regex, v);
  });

  return prompt.trim();
}

export const CODE_GENERATOR_TYPES = {
  SELENIUM_JAVA_PAGE_ONLY: 'Selenium-Java-Page-Only',
  CUCUMBER_ONLY: 'Cucumber-Only',
  CUCUMBER_WITH_SELENIUM_JAVA_STEPS: 'Cucumber-With-Selenium-Java-Steps',
  PLAYWRIGHT_PYTHON_SINGLE_FILE: 'Playwright-Python-Single-File',
  PLAYWRIGHT_PYTHON_POM: 'Playwright-Python-POM',
  PLAYWRIGHT_PYTHON_FEATURE: 'Playwright-Python-Feature',
};
